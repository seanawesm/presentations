# Schedules

One assistant, four jobs. Each job below is one scheduled task in Claude
Desktop. Run each one by hand once before letting it run on its own.

## supplier-desk — weekdays 08:00
```
Run the supplier-desk skill on new mail under the Gmail label Oakwyn since
the last run in progress.md. Only create drafts. Never send, delete or
archive anything. Show me the report, then replace progress.md.
```

## follow-ups — Mondays 08:30
```
Run the follow-ups skill and show me this week's follow-up list. Do not
change anything in Gmail. Then replace progress.md.
```

## gmail-cleanup — Manual (run it yourself with "Run now")
```
Run the gmail-cleanup skill. Stop after each step and wait for my answer.
Never trash anything I have not approved.
```

## weekly-report — Fridays 12:00 (create it PAUSED until IT approves)
```
Run the weekly-report skill. If the Microsoft 365 connector is not
connected, stop and tell me. Save the report as a draft for me.
```

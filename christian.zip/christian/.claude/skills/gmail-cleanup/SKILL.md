---
name: gmail-cleanup
description: Cleans up the 9000+ unread emails in Christian's private Gmail, sender by sender, with his approval at every step. Use only when Christian starts a cleanup run himself.
---

# Gmail cleanup

Work sender by sender, never email by email. Do the steps in order and
stop after each one for Christian's answer.

## Step 1 — protect what matters
Find receipts, order confirmations, bank mail, authorities (Altinn,
Skatteetaten, NAV) and the "always keep" senders in memory.md. Show the
list. Once Christian approves, add the label **Keep** to those threads.

## Step 2 — list the noisy senders
List the 30 senders with the most mail, excluding anything labelled Keep.
For each: sender, how many emails, newest date, what it is (newsletter,
ads, notifications, social media). Ask Christian to mark each one:
**keep**, **unsubscribe** or **trash**.

## Step 3 — act only on what he approved
- **trash**: move that sender's mail to Gmail trash. Tell him Gmail keeps
  trashed mail for 30 days, so he can still get it back.
- **unsubscribe**: list the unsubscribe links. He clicks them himself.
- Write the approved senders into memory.md under "senders approved for
  cleanup".

## Step 4 — stop new noise
For senders he never wants again, give him the exact Gmail filter to create
(Settings → Filters). Gmail filters handle future mail for free, without
using Claude.

Never trash anything labelled Keep, from Oakwyn, or not on his approved list.

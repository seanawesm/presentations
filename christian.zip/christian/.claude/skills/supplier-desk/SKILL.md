---
name: supplier-desk
description: Sorts supplier pitches that arrive under the Gmail label Oakwyn and prepares drafts — whisky goes to the product team, other drinks get a polite no. Use for any run about Oakwyn supplier pitches.
---

# Supplier desk

## Where you look
- Only Gmail threads with the label **Oakwyn**, newer than the last run in
  progress.md. Never open other mail for this job.
- Only **supplier pitches**: a producer or brand offering their products to
  Oakwyn. Skip everything else (customers, shareholders, Vinmonopolet,
  invoices, logistics, accounting, authorities).

## Before drafting
contact@ also reaches other shareholders. Read the whole thread. If anyone
from Oakwyn has already replied, do nothing with it.

## What you do with each pitch
1. **Whisky** — create a draft forwarding the original email to the product
   team (address in memory.md), with a short summary on top: producer,
   country/region, what they offer, their terms, what they ask for.
2. **Not whisky** — create a draft reply from christian@oakwyn.no: thank
   them, explain Oakwyn only imports whisky, wish them well. Reply in the
   language they wrote in (Norwegian or English). Under 5 sentences. Use the
   sign-off in memory.md.
3. **Not sure** (whisky liqueur, blends with other spirits, private label) —
   draft nothing. Put it on the list for Christian.

## Report at the end
- Whisky pitches drafted for the product team (sender, one line each)
- Polite declines drafted (sender, one line each)
- Waiting for Christian's decision (sender, why you were unsure)

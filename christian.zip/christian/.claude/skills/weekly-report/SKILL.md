---
name: weekly-report
description: Collects colleagues' weekly updates from Christian's work Microsoft 365 mail and fills his weekly report template. Use ONLY after his company's IT has approved the Microsoft 365 connector.
---

# Weekly work report

**Do not run this job until Christian confirms that his company's IT has
approved the Microsoft 365 connector.** If the connector is not connected,
stop and say so.

1. In Microsoft 365, read this week's updates from the colleagues listed in
   memory.md.
2. For each job in the portfolio, pull out: start date, whether the
   customer PO is issued, what will be delivered, estimated revenue, when it
   can be invoiced and the invoicing status.
3. Separately, pull out significant news: business development, technical
   milestone deliveries, customer meetings, commercial updates.
4. Fill Christian's report template (location in memory.md) with this,
   keeping its exact layout. Where something is missing, write
   `[MISSING: who / what]` instead of guessing.
5. Save the report as a draft for Christian. List which colleagues have not
   sent an update yet.

Work data never leaves Microsoft 365 and this report: never put it in
Gmail, memory.md or progress.md.

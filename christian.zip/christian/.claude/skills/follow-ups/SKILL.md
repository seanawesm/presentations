---
name: follow-ups
description: Builds Christian's weekly list of emails he left unread to come back to. Use for the Monday follow-up run or when he asks what he still needs to follow up.
---

# Follow-up list

Christian leaves emails unread as a reminder to come back to them. Respect
that habit: do not change anything in Gmail.

1. Look at unread mail from people (not newsletters, ads or notifications)
   received in the last 30 days, in all labels except the "always keep"
   automatic senders in memory.md.
2. Leave every email exactly as it is. Do not mark anything read, label,
   archive or move it.
3. Make one list, oldest first. For each email: who, the date, the subject,
   and one line on what it needs from him (answer, decision, payment,
   meeting, just read).
4. Put Oakwyn items in their own group at the top.

Keep the list short enough to read in two minutes. If there are more than
20 items, show the 20 oldest and say how many more there are.

# Christian's Email Assistant

One assistant that helps with your email. It has four jobs, and it only
ever prepares drafts and lists — you read and send everything yourself.

Open `diagram/email-strategy.html` in your browser for the full picture.

## What's in this folder

```
christian/
├── README.md            ← you are here
├── CLAUDE.md            ← the assistant's rules (your never-list lives here)
├── memory.md            ← facts about you it should remember
├── progress.md          ← what it did last time (it rewrites this itself)
├── SCHEDULES.md         ← the four jobs and when they run
├── diagram/             ← the email strategy picture
└── .claude/skills/      ← hidden folder: one skill per job
    ├── supplier-desk/   ← Oakwyn supplier pitches
    ├── follow-ups/      ← weekly list of emails you left unread
    ├── gmail-cleanup/   ← clearing the 9000+ unread, with your approval
    └── weekly-report/   ← work report (only after IT approves)
```

The `.claude` folder is hidden. Copy the whole `christian` folder, not just
the files you can see — otherwise the skills are left behind.
(Mac: Cmd + Shift + . in Finder shows hidden files.)

## The four jobs

| Job | Runs | What you get |
|---|---|---|
| Supplier desk | Weekdays 08:00 | Drafts in Gmail: whisky pitches to the product team with a summary, polite "no" to other drinks, and a list of pitches it wasn't sure about |
| Follow-up list | Mondays 08:30 | The emails you left unread to come back to, oldest first, one line each |
| Gmail cleanup | When you start it | Step-by-step cleanup, sender by sender. Nothing is trashed without your OK |
| Weekly work report | Fridays 12:00 | Your report template filled from colleagues' updates — **only after IT approves** |

## Setup — one time

### 1. Bring your mail into Gmail
- **Outlook.com:** Settings → Mail → Forwarding → forward to your Gmail.
  In Gmail, add a filter that gives these the label **Outlook**.
- **Oakwyn (Domeneshop):** on the mail server, forward christian@ to your
  Gmail. In Gmail, add a filter that gives these the label **Oakwyn**.
  Add christian@oakwyn.no under Gmail → Settings → Accounts → "Send mail as"
  so replies go out from your Oakwyn address.
- **invoice@** stays exactly as it is — it keeps going to Tripletex.
- **Work mail** is never forwarded. Ask your IT about the Microsoft 365
  connector instead.

### 2. Open the folder in Claude
Claude Desktop → **Code** tab → **Local** → choose this `christian` folder.

### 3. Connect Gmail
Settings → Connectors → Gmail → connect your private Gmail.

### 4. Fill in memory.md
Paste this into Claude:
```
Read CLAUDE.md and memory.md. Everything in [square brackets] is a
placeholder. Interview me one question at a time to fill them in, then
show me memory.md before saving.
```

### 5. Create the four scheduled jobs
The jobs can't be sent to you ready-made — Claude Desktop keeps the
schedule inside the app, not in a file. But Claude can set them up for you.
Paste this into Claude:
```
Read SCHEDULES.md. Create one local scheduled task for each job in it,
running in this folder, with the schedule and instruction shown. Create
weekly-report paused. Then list the tasks you created.
```
Check them under **Scheduled** in the sidebar.

### 6. Test each job once
Open each task and click **Run now**. When Claude asks for permission to use
Gmail, choose **Always allow** — then future runs won't stop and wait.
Read what it made before trusting it.

## Good to know
- Scheduled jobs only run while Claude Desktop is open and the computer is
  awake. If you miss one, it catches up once when you wake the computer.
  Turn on **Settings → This computer → Keep computer awake** if you want.
- Want it to remember something? Say "remember that…" and it updates
  memory.md.
- Want to change a rule? Edit CLAUDE.md, or ask Claude to.
- Oakwyn's company mail now sits in your private Gmail. That's a GDPR
  decision for you and the board — worth agreeing on together.

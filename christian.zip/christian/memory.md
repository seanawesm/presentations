# Memory — facts about Christian and his email

## Me
- Christian, Chairman of the Board, Oakwyn
- Sign-off for Oakwyn mail: [e.g. "Best regards, Christian — Chairman of the Board, Oakwyn"]
- Oakwyn replies go out from: christian@oakwyn.no

## Oakwyn product team
- Who: [names]
- Where whisky pitches go: [email address]
- What they want in the summary: [e.g. producer, region, range, terms, what they ask for]
- Whisky of special interest: [regions/styles — or "all high-quality whisky"]
- Not of interest: all other drinks (gin, vodka, wine, beer, liqueurs…)

## Gmail — always keep
- Receipts and order confirmations
- Banks: [names]
- Altinn, Skatteetaten, NAV and other authorities
- Memberships: [names]
- People who matter: [names / addresses]

## Gmail — senders approved for cleanup
- [filled in by the gmail-cleanup job after Christian approves]

## Weekly work report (only after IT approval)
- Template: [where it is — file in this folder or in OneDrive]
- Colleagues who send updates: [names]
- Day the report is due: [e.g. Friday 14:00]
